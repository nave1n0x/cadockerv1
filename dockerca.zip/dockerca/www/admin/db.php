<?php
$con = mysqli_connect("ca-mysql-app","naveenkumar","11903371","ca_db") or die(mysql_error());

?>